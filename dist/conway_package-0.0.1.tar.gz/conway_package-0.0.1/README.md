# Usage info

Start the game by executing the main.py file with python3:
python3 main.py
